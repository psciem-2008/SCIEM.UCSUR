# SCIEM UCSUR · Web + Spreadsheet CMS

## Arquitectura

Google Spreadsheet (CMS)
        ↓
Apps Script ligado al Spreadsheet (`Code.gs`)
        ↓
Endpoint público `/exec?action=bootstrap`
        ↓
GitHub Pages
`config.js` → `api.js` → `app.js` → `index.html`

Los dos deployments existentes quedan separados como `SERVICES.A` y `SERVICES.B`
hasta identificar con certeza qué función cumple cada uno.

## Archivos de GitHub

Sube a la raíz del repositorio:
- `index.html`
- `config.js`
- `api.js`
- `app.js`

## Configurar el CMS

1. Sube/importa `Pagina_web_SCIEM_UCSUR_CMS.xlsx` a Google Sheets.
2. Abre el Spreadsheet.
3. Ve a **Extensiones → Apps Script**.
4. Reemplaza `Code.gs` por el archivo `Code.gs` de este paquete.
5. Guarda.
6. Ejecuta manualmente `getHealth_` o `clearCmsCache` una vez para autorizar.
7. Ve a **Implementar → Nueva implementación → Aplicación web**.
8. Ejecutar como: tú.
9. Acceso: compatible con la web pública (si la cuenta lo permite).
10. Copia la URL que termina en `/exec`.
11. Pégala en `config.js`:
   `CONTENT_API: "https://script.google.com/macros/s/.../exec"`

## Prueba

Abre:
`TU_URL_EXEC?action=health`

Debe devolver JSON con:
`"status":"online"`

Luego:
`TU_URL_EXEC?action=bootstrap`

Debe devolver `config`, `sections`, `stats`, `areas`, `events`, etc.

## Cómo se actualiza la web

No edites GitHub para cambios de contenido.

En el Spreadsheet:
- `Configuracion`: hero, email, cifras, CTAs.
- `Secciones`: títulos y textos.
- `Estadisticas`: indicadores.
- `Areas`: áreas institucionales.
- `Eventos`: agenda.
- `Convocatorias`: oportunidades.
- `Equipo`: miembros visibles del equipo.
- `Investigacion`: proyectos.
- `Publicaciones`: producción científica.
- `Recursos`: enlaces y guías.
- `Documentos`: estatutos/reglamentos.
- `FAQ`: contenido de ayuda / SCIEM Bot.
- `Redes`: Instagram, Facebook, correo.
- `Servicios`: Apps Script externos.

Solo las filas con `Publicar = Sí` aparecen.

## Caché

El CMS usa caché por 5 minutos.
Si necesitas forzar una actualización inmediata:
- abre Apps Script,
- ejecuta `clearCmsCache()`.

También puedes bajar el tiempo cambiando:
`CMS_CACHE_SECONDS = 300`.
