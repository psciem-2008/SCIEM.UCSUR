const SCIEM_CONFIG = Object.freeze({
  // NUEVO deployment del Apps Script ligado al Spreadsheet CMS.
  // Ejemplo:
  // CONTENT_API: "https://script.google.com/macros/s/AKfy.../exec"
  CONTENT_API: "PEGA_AQUI_EL_ENDPOINT_DEL_CMS",

  // Tus dos Web Apps actuales. Se mantienen separados del CMS
  // hasta confirmar exactamente qué función cumple cada uno.
  SERVICES: {
    A: "https://script.google.com/macros/s/AKfycbx6sEgvFD41nzq08RUAn6lEht4EwtMMdWeRwtohtlqIgDCNM9uCkYjD1AqRhL08lVZb/exec",
    B: "https://script.google.com/macros/s/AKfycby63uAqfVHCZCy5168Z1_X9WgYljCiLM19a3UyXdVIN9A3OYp4LCDhmfi2vETZIFuCitQ/exec"
  },

  TIMEOUT: 15000,
  DEBUG: true
});
