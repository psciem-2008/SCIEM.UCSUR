(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  const esc = (value = "") =>
    String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");

  const safeUrl = (url = "#") => {
    const value = String(url || "").trim();
    if (!value) return "#";
    if (
      value.startsWith("#") ||
      value.startsWith("mailto:") ||
      value.startsWith("https://") ||
      value.startsWith("http://")
    ) return value;
    return "#";
  };

  const formatDate = (value) => {
    if (!value) return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return null;
    return {
      month: d.toLocaleDateString("es-PE", { month: "short" }).replace(".", "").toUpperCase(),
      day: String(d.getDate()).padStart(2, "0"),
      full: d.toLocaleDateString("es-PE", { day: "2-digit", month: "long", year: "numeric" })
    };
  };

  const byOrder = (a, b) =>
    Number(a.Orden ?? a.orden ?? 999) - Number(b.Orden ?? b.orden ?? 999);

  function setText(selector, value) {
    const el = $(selector);
    if (el && value !== undefined && value !== null && value !== "") {
      el.textContent = value;
    }
  }

  function applyConfig(config = {}) {
    const c = config;

    setText("#brand-name", c.site_title);
    setText("#footer-brand-name", c.site_title);
    setText("#hero-eyebrow", c.hero_eyebrow);
    setText("#hero-title-1", c.hero_title_1);
    setText("#hero-title-em", c.hero_title_em);
    setText("#hero-title-2", c.hero_title_2);
    setText("#hero-text", c.hero_text);
    setText("#member-count", c.members_count);
    setText("#member-label", c.members_label);
    setText("#year-location", `${c.year || new Date().getFullYear()} · ${c.city_country || "Lima, Perú"}`);

    const p = $("#hero-primary");
    if (p) {
      p.textContent = `${c.hero_cta_primary_text || "Conócenos"} →`;
      p.href = safeUrl(c.hero_cta_primary_url || "#nosotros");
    }

    const s = $("#hero-secondary");
    if (s) {
      s.textContent = c.hero_cta_secondary_text || "Ver actividades";
      s.href = safeUrl(c.hero_cta_secondary_url || "#eventos");
    }

    $$("[data-membership-cta]").forEach((el) => {
      el.textContent = `${c.membership_cta_text || "Quiero ser parte"} →`;
      el.href = safeUrl(c.membership_cta_url || "#");
    });

    $$("[data-contact-email]").forEach((el) => {
      if (c.contact_email) {
        el.href = `mailto:${c.contact_email}`;
        if (el.dataset.showEmail === "true") el.textContent = c.contact_email;
      }
    });
  }

  function applySections(sections = []) {
    sections.forEach((row) => {
      const id = String(row.Seccion || row.seccion || "").trim().toLowerCase();
      if (!id) return;

      setText(`#${id}-eyebrow`, row.Eyebrow);
      setText(`#${id}-title`, row.Titulo);
      setText(`#${id}-copy`, row["Texto destacado"] || row.Texto);
      setText(`#${id}-secondary`, row["Texto secundario"]);

      const cta = $(`#${id}-cta`);
      if (cta && row["CTA texto"]) {
        cta.textContent = `${row["CTA texto"]} →`;
        cta.href = safeUrl(row["CTA URL"]);
      }
    });
  }

  function renderStats(rows = []) {
    const root = $("#stats-grid");
    if (!root || !rows.length) return;

    root.innerHTML = rows.sort(byOrder).map((r) => `
      <article class="number-card">
        <strong>${esc(r.Valor)}</strong>
        <span>${esc(r.Etiqueta)}</span>
      </article>
    `).join("");
  }

  function renderAreas(rows = []) {
    const root = $("#areas-grid");
    if (!root || !rows.length) return;

    root.innerHTML = rows.sort(byOrder).map((r, i) => `
      <article class="area-card">
        <span>${String(i + 1).padStart(2, "0")}</span>
        <div class="area-icon" aria-hidden="true">${esc(r.Icono || "✦")}</div>
        <h3>${esc(r.Nombre)}</h3>
        <p>${esc(r.Descripción)}</p>
        <a href="${safeUrl(r.URL)}">Explorar →</a>
      </article>
    `).join("");
  }

  function renderEvents(rows = []) {
    const root = $("#event-list");
    if (!root) return;

    if (!rows.length) {
      root.innerHTML = `<div class="empty-state">No hay actividades publicadas por el momento.</div>`;
      return;
    }

    root.innerHTML = rows
      .sort((a, b) => new Date(a.Fecha) - new Date(b.Fecha))
      .map((r) => {
        const d = formatDate(r.Fecha) || { month: "", day: "" };
        const meta = [r.Lugar, r.Modalidad].filter(Boolean).join(" · ");

        return `
          <article class="event">
            <div class="date">
              <small>${esc(d.month)}</small>
              <strong>${esc(d.day)}</strong>
            </div>
            <span class="event-type">${esc(r.Tipo || "ACTIVIDAD")}</span>
            <div>
              <h3>${esc(r.Título)}</h3>
              <p>${esc(meta)}</p>
            </div>
            <a href="${safeUrl(r.URL)}" aria-label="Abrir ${esc(r.Título)}">↗</a>
          </article>
        `;
      }).join("");
  }

  function renderCards(rootSelector, rows, mapper, emptyText) {
    const root = $(rootSelector);
    if (!root) return;

    if (!rows?.length) {
      root.innerHTML = `<div class="empty-state">${esc(emptyText)}</div>`;
      return;
    }

    root.innerHTML = rows.sort(byOrder).map(mapper).join("");
  }

  function renderCalls(rows = []) {
    renderCards("#calls-grid", rows, (r) => {
      const close = formatDate(r.Cierre);
      return `
        <article class="content-card">
          <div class="card-kicker">${esc(r.Tipo || "CONVOCATORIA")}</div>
          <h3>${esc(r.Título)}</h3>
          <p>${esc(r.Resumen)}</p>
          <div class="card-meta">
            <span class="tag">${esc(r.Estado || "")}</span>
            ${close ? `<span>Cierre: ${esc(close.full)}</span>` : ""}
          </div>
          <a class="card-link" href="${safeUrl(r.URL)}">Ver convocatoria →</a>
        </article>`;
    }, "No hay convocatorias publicadas.");
  }

  function renderResearch(rows = []) {
    renderCards("#research-grid", rows, (r) => `
      <article class="content-card">
        <div class="card-kicker">${esc(r.Línea || "INVESTIGACIÓN")}</div>
        <h3>${esc(r.Título)}</h3>
        <p>${esc(r.Resumen)}</p>
        <div class="card-meta">
          <span class="tag">${esc(r.Estado || "")}</span>
          <span>${esc(r["Investigadores/Equipo"] || "")}</span>
        </div>
        ${r.URL ? `<a class="card-link" href="${safeUrl(r.URL)}">Conocer proyecto →</a>` : ""}
      </article>
    `, "Aún no hay proyectos publicados.");
  }

  function renderPublications(rows = []) {
    renderCards("#publications-grid", rows, (r) => `
      <article class="publication">
        <div>
          <span class="publication-year">${esc(r.Año || "")}</span>
          <h3>${esc(r.Título)}</h3>
          <p>${esc(r.Autores || "")}</p>
        </div>
        <div class="publication-right">
          <span>${esc(r["Revista/Evento"] || r.Tipo || "")}</span>
          ${r["DOI/URL"] ? `<a href="${safeUrl(r["DOI/URL"])}">Abrir ↗</a>` : ""}
        </div>
      </article>
    `, "Aún no hay publicaciones cargadas.");
  }

  function renderTeam(rows = []) {
    renderCards("#team-grid", rows, (r) => `
      <article class="person-card">
        <div class="avatar">
          ${r["Foto URL"]
            ? `<img src="${safeUrl(r["Foto URL"])}" alt="${esc(r.Nombre)}" loading="lazy">`
            : esc((r.Nombre || "?").trim().charAt(0).toUpperCase())
          }
        </div>
        <h3>${esc(r.Nombre)}</h3>
        <p>${esc(r.Cargo)}</p>
        <small>${esc(r.Área || "")} · ${esc(r.Periodo || "")}</small>
      </article>
    `, "El equipo se publicará próximamente.");
  }

  function renderResources(rows = []) {
    renderCards("#resources-grid", rows, (r) => `
      <a class="resource-card" href="${safeUrl(r.URL)}">
        <span>${esc(r.Categoría || "RECURSO")}</span>
        <h3>${esc(r.Título)}</h3>
        <p>${esc(r.Descripción)}</p>
        <b>${esc(r.Icono || "↗")}</b>
      </a>
    `, "No hay recursos publicados.");
  }

  function renderDocuments(rows = []) {
    renderCards("#documents-grid", rows, (r) => `
      <a class="document-row" href="${safeUrl(r.URL)}">
        <div>
          <span>${esc(r.Categoría || "DOCUMENTO")} · ${esc(r["Versión/Año"] || "")}</span>
          <h3>${esc(r.Título)}</h3>
          <p>${esc(r.Descripción)}</p>
        </div>
        <b>↗</b>
      </a>
    `, "No hay documentos publicados.");
  }

  function renderFaq(rows = []) {
    const root = $("#faq-list");
    if (!root) return;

    root.innerHTML = rows.sort(byOrder).map((r) => `
      <details class="faq-item">
        <summary>${esc(r.Pregunta)}</summary>
        <p>${esc(r.Respuesta)}</p>
        ${r["CTA texto"]
          ? `<a href="${safeUrl(r["CTA URL"])}">${esc(r["CTA texto"])} →</a>`
          : ""
        }
      </details>
    `).join("");
  }

  function renderSocial(rows = []) {
    const roots = $$(".social-links");
    if (!roots.length || !rows.length) return;

    const html = rows.sort(byOrder).map((r) => `
      <a href="${safeUrl(r.URL)}" target="${String(r.URL || "").startsWith("http") ? "_blank" : "_self"}"
         rel="noopener">${esc(r.Red)}</a>
    `).join("");

    roots.forEach((root) => root.innerHTML = html);
  }

  function initMenu() {
    const button = $("#menu-button");
    const panel = $("#mobile-panel");
    if (!button || !panel) return;

    const close = () => {
      panel.classList.remove("open");
      button.setAttribute("aria-expanded", "false");
      document.body.classList.remove("menu-open");
    };

    button.addEventListener("click", () => {
      const open = panel.classList.toggle("open");
      button.setAttribute("aria-expanded", String(open));
      document.body.classList.toggle("menu-open", open);
    });

    $$("a", panel).forEach(a => a.addEventListener("click", close));
  }

  async function boot() {
    initMenu();

    try {
      const payload = await SCIEMApi.cms({ action: "bootstrap" });

      if (!payload?.ok || !payload?.data) {
        throw new Error(payload?.error || "Respuesta inesperada del CMS.");
      }

      const d = payload.data;

      applyConfig(d.config || {});
      applySections(d.sections || []);
      renderStats(d.stats || []);
      renderAreas(d.areas || []);
      renderEvents(d.events || []);
      renderCalls(d.calls || []);
      renderResearch(d.research || []);
      renderPublications(d.publications || []);
      renderTeam(d.team || []);
      renderResources(d.resources || []);
      renderDocuments(d.documents || []);
      renderFaq(d.faq || []);
      renderSocial(d.social || []);

      document.documentElement.dataset.cms = "online";

      if (SCIEM_CONFIG.DEBUG) {
        console.log("✅ CMS SCIEM cargado", d);
      }
    } catch (error) {
      console.error("❌ No se pudo cargar el CMS:", error);
      document.documentElement.dataset.cms = "fallback";
      // El HTML conserva contenido de respaldo para que la web no quede vacía.
    }
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
