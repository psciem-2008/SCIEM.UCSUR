class SCIEMApi {
  static async request(url, params = {}) {
    if (!url || url.includes("PEGA_AQUI")) {
      throw new Error("CONTENT_API todavía no está configurado.");
    }

    const endpoint = new URL(url);

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        endpoint.searchParams.set(key, value);
      }
    });

    const controller = new AbortController();
    const timer = setTimeout(
      () => controller.abort(),
      SCIEM_CONFIG.TIMEOUT || 15000
    );

    try {
      if (SCIEM_CONFIG.DEBUG) {
        console.log("[SCIEM API]", endpoint.toString());
      }

      const response = await fetch(endpoint.toString(), {
        method: "GET",
        redirect: "follow",
        cache: "no-store",
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const text = await response.text();

      try {
        return JSON.parse(text);
      } catch {
        throw new Error("La API no devolvió JSON válido.");
      }
    } finally {
      clearTimeout(timer);
    }
  }

  static cms(params = {}) {
    return this.request(SCIEM_CONFIG.CONTENT_API, params);
  }

  static serviceA(params = {}) {
    return this.request(SCIEM_CONFIG.SERVICES.A, params);
  }

  static serviceB(params = {}) {
    return this.request(SCIEM_CONFIG.SERVICES.B, params);
  }
}
