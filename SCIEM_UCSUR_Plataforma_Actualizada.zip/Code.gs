/**
 * SCIEM UCSUR · CMS API
 * Vincula este Apps Script al Google Spreadsheet "Página web SCIEM UCSUR".
 * Despliega como Web App y pega su URL /exec en config.js -> CONTENT_API.
 */

const CMS_CACHE_SECONDS = 300;

function doGet(e) {
  try {
    const action = String((e && e.parameter && e.parameter.action) || "bootstrap")
      .trim()
      .toLowerCase();

    const routes = {
      bootstrap: getBootstrap_,
      config: () => getConfig_(),
      sections: () => getRows_("Secciones"),
      stats: () => getRows_("Estadisticas"),
      areas: () => getRows_("Areas"),
      events: () => getRows_("Eventos"),
      calls: () => getRows_("Convocatorias"),
      team: () => getRows_("Equipo"),
      research: () => getRows_("Investigacion"),
      publications: () => getRows_("Publicaciones"),
      resources: () => getRows_("Recursos"),
      documents: () => getRows_("Documentos"),
      faq: () => getRows_("FAQ"),
      social: () => getRows_("Redes"),
      services: () => getRows_("Servicios"),
      health: getHealth_
    };

    const handler = routes[action];

    if (!handler) {
      return json_({
        ok: false,
        error: "Acción no válida",
        allowed: Object.keys(routes)
      });
    }

    return json_({
      ok: true,
      action,
      generatedAt: new Date().toISOString(),
      data: handler()
    });

  } catch (error) {
    console.error(error);

    return json_({
      ok: false,
      error: "Error interno del CMS",
      message: String(error && error.message || error)
    });
  }
}


function getBootstrap_() {
  const cache = CacheService.getScriptCache();
  const key = "SCIEM_BOOTSTRAP_V1";
  const cached = cache.get(key);

  if (cached) {
    return JSON.parse(cached);
  }

  const data = {
    config: getConfig_(),
    sections: getRows_("Secciones"),
    stats: getRows_("Estadisticas"),
    areas: getRows_("Areas"),
    events: getRows_("Eventos"),
    calls: getRows_("Convocatorias"),
    team: getRows_("Equipo"),
    research: getRows_("Investigacion"),
    publications: getRows_("Publicaciones"),
    resources: getRows_("Recursos"),
    documents: getRows_("Documentos"),
    faq: getRows_("FAQ"),
    social: getRows_("Redes"),
    services: getRows_("Servicios")
  };

  cache.put(key, JSON.stringify(data), CMS_CACHE_SECONDS);
  return data;
}


function getConfig_() {
  const sheet = getSheet_("Configuracion");
  const values = sheet.getDataRange().getValues();

  if (values.length < 2) return {};

  const headers = values[0].map(String);
  const idxKey = headers.indexOf("Clave");
  const idxValue = headers.indexOf("Valor");
  const idxPublish = headers.indexOf("Publicar");

  const result = {};

  values.slice(1).forEach(row => {
    if (idxPublish >= 0 && !isPublished_(row[idxPublish])) return;

    const key = String(row[idxKey] || "").trim();
    if (!key) return;

    result[key] = normalizeValue_(row[idxValue]);
  });

  return result;
}


function getRows_(sheetName) {
  const sheet = getSheet_(sheetName);
  const values = sheet.getDataRange().getValues();

  if (values.length < 2) return [];

  const headers = values[0].map(h => String(h || "").trim());
  const publishIndex = headers.indexOf("Publicar");

  const rows = values
    .slice(1)
    .filter(row => row.some(v => String(v || "").trim() !== ""))
    .filter(row => publishIndex < 0 || isPublished_(row[publishIndex]))
    .map(row => {
      const obj = {};

      headers.forEach((header, i) => {
        if (!header) return;
        obj[header] = normalizeValue_(row[i]);
      });

      return obj;
    });

  const orderIndex = headers.indexOf("Orden");

  if (orderIndex >= 0) {
    rows.sort((a, b) => Number(a.Orden || 9999) - Number(b.Orden || 9999));
  }

  return rows;
}


function getHealth_() {
  return {
    service: "SCIEM UCSUR CMS",
    status: "online",
    spreadsheet: SpreadsheetApp.getActiveSpreadsheet().getName(),
    timestamp: new Date().toISOString()
  };
}


function getSheet_(name) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);

  if (!sheet) {
    throw new Error(`No existe la hoja "${name}".`);
  }

  return sheet;
}


function isPublished_(value) {
  const v = String(value || "").trim().toLowerCase();
  return ["sí", "si", "yes", "true", "1"].includes(v);
}


function normalizeValue_(value) {
  if (value instanceof Date) {
    return Utilities.formatDate(
      value,
      Session.getScriptTimeZone() || "America/Lima",
      "yyyy-MM-dd'T'HH:mm:ssXXX"
    );
  }

  return value;
}


function json_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}


/**
 * Ejecuta esta función manualmente si deseas vaciar la caché
 * inmediatamente después de una actualización importante.
 */
function clearCmsCache() {
  CacheService.getScriptCache().remove("SCIEM_BOOTSTRAP_V1");
}
